**START HERE: README_GANTRY_FIX.md** — use the new default Stage 23 kinematic gantry worlds.

Stage 23 all-surfaces extension. Read README_STAGE23.md first; Stage 22 docs retained for baseline.
